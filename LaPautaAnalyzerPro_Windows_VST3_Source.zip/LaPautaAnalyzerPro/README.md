# LA PAUTA ANALYZER PRO

Plugin VST3 de análisis de espectro para Windows de 64 bits, creado con JUCE 8.0.6.

## Qué incluye
- Analizador FFT en tiempo real.
- Barras de espectro de 20 Hz a 20 kHz.
- Curva dorada de peak-hold y curva blanca suavizada.
- Escala vertical en dB y frecuencia logarítmica.
- Interfaz negra con detalles dorados y blancos.
- Audio transparente: el plugin deja pasar la señal sin modificarla.

## Compilar en Windows
Requisitos:
- Windows 10/11 de 64 bits.
- Visual Studio 2022 con el componente "Desktop development with C++".
- CMake 3.22 o superior.
- Conexión a Internet durante la primera configuración para descargar JUCE 8.0.6.

Desde la carpeta del proyecto, abre PowerShell:

```powershell
cmake -S . -B build -A x64
cmake --build build --config Release
```

El VST3 normalmente se genera en:

`build/LaPautaAnalyzerPro_artefacts/Release/VST3/La Pauta Analyzer Pro.vst3`

Copia esa carpeta `.vst3` a:

`C:\\Program Files\\Common Files\\VST3`

Después abre REAPER y ejecuta una búsqueda/rescan de plugins.

## Compilación automática
El workflow de GitHub Actions incluido compila el proyecto en `windows-latest` y publica el VST3 como artefacto descargable.

## Importante
Este ZIP contiene el proyecto fuente completo, no un binario VST3 ya compilado. La primera compilación necesita descargar JUCE. El funcionamiento visual y el paso de audio deben comprobarse en REAPER después de compilar.
