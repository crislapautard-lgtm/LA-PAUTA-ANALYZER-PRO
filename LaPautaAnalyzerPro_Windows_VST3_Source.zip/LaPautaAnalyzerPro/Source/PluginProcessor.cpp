#include "PluginProcessor.h"
#include "PluginEditor.h"

LaPautaAnalyzerProAudioProcessor::LaPautaAnalyzerProAudioProcessor()
    : AudioProcessor(BusesProperties()
        .withInput("Input", juce::AudioChannelSet::stereo(), true)
        .withOutput("Output", juce::AudioChannelSet::stereo(), true))
{
    for (auto& sample : analysisRing)
        sample.store(0.0f, std::memory_order_relaxed);
}

const juce::String LaPautaAnalyzerProAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

void LaPautaAnalyzerProAudioProcessor::prepareToPlay(double, int)
{
    // The analyzer is transparent: it does not alter the incoming audio.
}

void LaPautaAnalyzerProAudioProcessor::releaseResources()
{
}

bool LaPautaAnalyzerProAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto input = layouts.getMainInputChannelSet();
    const auto output = layouts.getMainOutputChannelSet();

    if (input != output)
        return false;

    return input == juce::AudioChannelSet::mono()
        || input == juce::AudioChannelSet::stereo();
}

void LaPautaAnalyzerProAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer,
                                                     juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    midiMessages.clear();

    // Pass the audio through unchanged while sending a mono analysis feed
    // to the editor using atomic samples (no locks on the audio thread).
    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();

    if (channels <= 0)
        return;

    const float* left = buffer.getReadPointer(0);
    const float* right = channels > 1 ? buffer.getReadPointer(1) : left;

    auto position = writePosition.load(std::memory_order_relaxed);

    for (int i = 0; i < samples; ++i)
    {
        const float mono = 0.5f * (left[i] + right[i]);
        analysisRing[static_cast<size_t>(position) & (fftSize - 1)]
            .store(mono, std::memory_order_relaxed);
        ++position;
    }

    writePosition.store(position, std::memory_order_release);
}


float LaPautaAnalyzerProAudioProcessor::getAnalysisSample(int index) const noexcept
{
    if (index < 0 || index >= fftSize)
        return 0.0f;

    return analysisRing[static_cast<size_t>(index)].load(std::memory_order_relaxed);
}


juce::AudioProcessorEditor* LaPautaAnalyzerProAudioProcessor::createEditor()
{
    return new LaPautaAnalyzerProAudioProcessorEditor(*this);
}

void LaPautaAnalyzerProAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    destData.reset();
}

void LaPautaAnalyzerProAudioProcessor::setStateInformation(const void*, int)
{
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new LaPautaAnalyzerProAudioProcessor();
}
