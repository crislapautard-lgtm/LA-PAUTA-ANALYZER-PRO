#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"
#include <array>

class LaPautaAnalyzerProAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                     private juce::Timer
{
public:
    explicit LaPautaAnalyzerProAudioProcessorEditor(LaPautaAnalyzerProAudioProcessor&);
    ~LaPautaAnalyzerProAudioProcessorEditor() override = default;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void calculateSpectrum();

    LaPautaAnalyzerProAudioProcessor& audioProcessor;
    juce::dsp::FFT fft { LaPautaAnalyzerProAudioProcessor::fftOrder };
    juce::dsp::WindowingFunction<float> window {
        LaPautaAnalyzerProAudioProcessor::fftSize,
        juce::dsp::WindowingFunction<float>:: hann
    };

    std::array<float, LaPautaAnalyzerProAudioProcessor::fftSize * 2> fftData {};
    std::array<float, 64> barLevels {};
    std::array<float, 64> peakLevels {};
    std::array<float, 64> smoothLevels {};

    juce::uint64 lastReadPosition = 0;
    juce::Rectangle<int> graphArea;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(LaPautaAnalyzerProAudioProcessorEditor)
};
