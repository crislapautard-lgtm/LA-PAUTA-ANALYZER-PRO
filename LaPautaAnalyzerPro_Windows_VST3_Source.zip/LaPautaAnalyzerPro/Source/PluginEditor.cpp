#include "PluginEditor.h"

namespace
{
    constexpr int numberOfBands = 64;
    constexpr float minDb = -72.0f;
    constexpr float maxDb = 0.0f;

    float dbToY(float db, float top, float height)
    {
        const float normalized = juce::jlimit(0.0f, 1.0f, (db - minDb) / (maxDb - minDb));
        return top + height * (1.0f - normalized);
    }

    juce::Colour backgroundColour() { return juce::Colour(0xff080a0d); }
    juce::Colour panelColour()      { return juce::Colour(0xff10151b); }
    juce::Colour goldColour()       { return juce::Colour(0xffd8b45a); }
    juce::Colour whiteColour()      { return juce::Colour(0xffe8edf2); }
}

LaPautaAnalyzerProAudioProcessorEditor::LaPautaAnalyzerProAudioProcessorEditor(
    LaPautaAnalyzerProAudioProcessor& processor)
    : AudioProcessorEditor(&processor), audioProcessor(processor)
{
    setSize(1100, 620);
    setResizable(true, true);
    setResizeLimits(760, 460, 1800, 1100);
    startTimerHz(30);
}

void LaPautaAnalyzerProAudioProcessorEditor::resized()
{
    graphArea = getLocalBounds().reduced(34, 110).withTrimmedBottom(54);
}

void LaPautaAnalyzerProAudioProcessorEditor::timerCallback()
{
    const auto currentPosition = audioProcessor.getWritePosition();
    if (currentPosition == lastReadPosition)
        return;

    calculateSpectrum();
    lastReadPosition = currentPosition;
    repaint();
}

void LaPautaAnalyzerProAudioProcessorEditor::calculateSpectrum()
{
    constexpr int fftSize = LaPautaAnalyzerProAudioProcessor::fftSize;
    const auto writePos = audioProcessor.getWritePosition();

    if (writePos < static_cast<uint64_t>(fftSize))
        return;

    for (int i = 0; i < fftSize; ++i)
    {
        const auto ringIndex = static_cast<int>((writePos - fftSize + static_cast<uint64_t>(i))
                                                & static_cast<uint64_t>(fftSize - 1));
        fftData[static_cast<size_t>(i)] = audioProcessor.getAnalysisSample(ringIndex);
    }

    std::fill(fftData.begin() + fftSize, fftData.end(), 0.0f);
    window.multiplyWithWindowingTable(fftData.data(), fftSize);
    fft.performFrequencyOnlyForwardTransform(fftData.data());

    const double sampleRate = juce::jmax(22050.0, audioProcessor.getSampleRate());
    constexpr float lowestHz = 20.0f;
    constexpr float highestHz = 20000.0f;

    for (int band = 0; band < numberOfBands; ++band)
    {
        const float x0 = static_cast<float>(band) / static_cast<float>(numberOfBands);
        const float x1 = static_cast<float>(band + 1) / static_cast<float>(numberOfBands);
        const float lowHz = lowestHz * std::pow(highestHz / lowestHz, x0);
        const float highHz = lowestHz * std::pow(highestHz / lowestHz, x1);

        int firstBin = juce::jlimit(1, fftSize / 2 - 1,
            static_cast<int>(lowHz * static_cast<float>(fftSize) / static_cast<float>(sampleRate)));
        int lastBin = juce::jlimit(firstBin + 1, fftSize / 2,
            static_cast<int>(highHz * static_cast<float>(fftSize) / static_cast<float>(sampleRate)));

        float magnitude = 0.0f;
        for (int bin = firstBin; bin < lastBin; ++bin)
            magnitude = juce::jmax(magnitude, fftData[static_cast<size_t>(bin)]);

        const float normalized = juce::jlimit(0.0f, 1.0f, magnitude / 120.0f);
        const float db = juce::jlimit(minDb, maxDb, juce::Decibels::gainToDecibels(normalized, minDb));

        barLevels[static_cast<size_t>(band)] = db;
        smoothLevels[static_cast<size_t>(band)] =
            0.72f * smoothLevels[static_cast<size_t>(band)] + 0.28f * db;
        peakLevels[static_cast<size_t>(band)] =
            juce::jmax(db, peakLevels[static_cast<size_t>(band)] - 0.7f);
    }
}

void LaPautaAnalyzerProAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(backgroundColour());

    auto bounds = getLocalBounds();
    auto header = bounds.removeFromTop(82);

    g.setColour(panelColour());
    g.fillRoundedRectangle(header.toFloat().reduced(18, 10), 12.0f);

    g.setColour(goldColour());
    g.setFont(juce::Font(juce::FontOptions(25.0f, juce::Font::bold)));
    g.drawText("LA PAUTA", 38, 18, 190, 30, juce::Justification::centredLeft);

    g.setColour(whiteColour());
    g.setFont(juce::Font(juce::FontOptions(18.0f, juce::Font::bold)));
    g.drawText("ANALYZER PRO", 188, 21, 260, 26, juce::Justification::centredLeft);

    g.setColour(juce::Colour(0xff89939e));
    g.setFont(juce::Font(juce::FontOptions(11.0f)));
    g.drawText("REAL-TIME SPECTRUM  |  20 Hz — 20 kHz  |  STEREO INPUT",
               40, 52, 500, 18, juce::Justification::centredLeft);

    auto graph = graphArea.toFloat();
    g.setColour(panelColour());
    g.fillRoundedRectangle(graph, 10.0f);

    // Horizontal dB grid.
    g.setFont(juce::Font(11.0f));
    for (int db = 0; db >= -70; db -= 10)
    {
        const float y = dbToY(static_cast<float>(db), graph.getY(), graph.getHeight());
        g.setColour(juce::Colour(0xff29323b));
        g.drawHorizontalLine(static_cast<int>(y), graph.getX(), graph.getRight());
        g.setColour(juce::Colour(0xff9aa4ad));
        g.drawText(juce::String(db), 5, static_cast<int>(y) - 8, 26, 16,
                   juce::Justification::centredRight);
        g.drawText(juce::String(db), getWidth() - 30, static_cast<int>(y) - 8, 26, 16,
                   juce::Justification::centredLeft);
    }

    // Logarithmic frequency grid and labels.
    const std::array<float, 10> frequencies { 20.0f, 50.0f, 100.0f, 200.0f, 500.0f,
                                              1000.0f, 2000.0f, 5000.0f, 10000.0f, 20000.0f };
    for (auto frequency : frequencies)
    {
        const float normalized = std::log(frequency / 20.0f) / std::log(20000.0f / 20.0f);
        const float x = graph.getX() + normalized * graph.getWidth();
        g.setColour(juce::Colour(0xff27313a));
        g.drawVerticalLine(static_cast<int>(x), graph.getY(), graph.getBottom());
        g.setColour(juce::Colour(0xffb2bac2));
        juce::String label;
        if (frequency >= 1000.0f)
            label = juce::String(frequency / 1000.0f, frequency == 1000.0f ? 0 : 0) + "k";
        else
            label = juce::String(static_cast<int>(frequency));
        g.drawText(label, static_cast<int>(x) - 22, graph.getBottom() + 10, 46, 18,
                   juce::Justification::centred);
    }

    // White spectrum bars.
    const float slotWidth = graph.getWidth() / static_cast<float>(numberOfBands);
    for (int i = 0; i < numberOfBands; ++i)
    {
        const float x = graph.getX() + static_cast<float>(i) * slotWidth;
        const float y = dbToY(barLevels[static_cast<size_t>(i)], graph.getY(), graph.getHeight());
        auto bar = juce::Rectangle<float>(x + 1.5f, y, juce::jmax(1.0f, slotWidth - 3.0f),
                                          graph.getBottom() - y);
        g.setColour(juce::Colour(0xffdce3e9).withAlpha(0.90f));
        g.fillRoundedRectangle(bar, 1.2f);
    }

    // Gold peak-hold curve.
    juce::Path peakPath;
    for (int i = 0; i < numberOfBands; ++i)
    {
        const float x = graph.getX() + (static_cast<float>(i) + 0.5f) * slotWidth;
        const float y = dbToY(peakLevels[static_cast<size_t>(i)], graph.getY(), graph.getHeight());
        if (i == 0) peakPath.startNewSubPath(x, y);
        else peakPath.lineTo(x, y);
    }
    g.setColour(goldColour());
    g.strokePath(peakPath, juce::PathStrokeType(2.0f, juce::PathStrokeType::curved));

    // Smooth white average curve.
    juce::Path smoothPath;
    for (int i = 0; i < numberOfBands; ++i)
    {
        const float x = graph.getX() + (static_cast<float>(i) + 0.5f) * slotWidth;
        const float y = dbToY(smoothLevels[static_cast<size_t>(i)], graph.getY(), graph.getHeight());
        if (i == 0) smoothPath.startNewSubPath(x, y);
        else smoothPath.lineTo(x, y);
    }
    g.setColour(whiteColour().withAlpha(0.95f));
    g.strokePath(smoothPath, juce::PathStrokeType(1.8f, juce::PathStrokeType::curved));

    g.setColour(juce::Colour(0xff68737e));
    g.setFont(juce::Font(11.0f));
    g.drawText("BARS: LIVE LEVEL     GOLD: PEAK HOLD     WHITE: SMOOTH RESPONSE",
               38, getHeight() - 25, getWidth() - 76, 16, juce::Justification::centredLeft);
}
