cmake_minimum_required(VERSION 3.22)

project(LaPautaAnalyzerPro VERSION 1.0.0 LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

include(FetchContent)
FetchContent_Declare(
    JUCE
    GIT_REPOSITORY https://github.com/juce-framework/JUCE.git
    GIT_TAG 8.0.6
    GIT_SHALLOW TRUE
)
FetchContent_MakeAvailable(JUCE)

juce_add_plugin(LaPautaAnalyzerPro
    COMPANY_NAME "La Pauta"
    BUNDLE_ID "com.lapauta.analyzerpro"
    PLUGIN_MANUFACTURER_CODE LpTa
    PLUGIN_CODE LpA1
    PRODUCT_NAME "La Pauta Analyzer Pro"
    DESCRIPTION "Real-time stereo spectrum analyzer"
    IS_SYNTH FALSE
    NEEDS_MIDI_INPUT FALSE
    NEEDS_MIDI_OUTPUT FALSE
    IS_MIDI_EFFECT FALSE
    EDITOR_WANTS_KEYBOARD_FOCUS FALSE
    COPY_PLUGIN_AFTER_BUILD FALSE
    PLUGIN_CHANNEL_CONFIGURATIONS
        "{1,1}"
        "{2,2}"
    FORMATS VST3
)

juce_generate_juce_header(LaPautaAnalyzerPro)

target_sources(LaPautaAnalyzerPro PRIVATE
    Source/PluginProcessor.cpp
    Source/PluginProcessor.h
    Source/PluginEditor.cpp
    Source/PluginEditor.h
)

target_compile_definitions(LaPautaAnalyzerPro PUBLIC
    JUCE_WEB_BROWSER=0
    JUCE_USE_CURL=0
    JUCE_VST3_CAN_REPLACE_VST2=0
)

target_link_libraries(LaPautaAnalyzerPro PRIVATE
    juce::juce_audio_utils
    juce::juce_dsp
    PUBLIC
    juce::juce_recommended_config_flags
    juce::juce_recommended_lto_flags
    juce::juce_recommended_warning_flags
)
